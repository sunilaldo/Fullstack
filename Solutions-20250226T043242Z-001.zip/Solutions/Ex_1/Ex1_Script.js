document.getElementById("myForm").addEventListener("submit", function(event) {
    let isValid = true;

    // Clear previous errors
    document.getElementById("usernameError").innerText = "";
    document.getElementById("emailError").innerText = "";
    document.getElementById("passwordError").innerText = "";

    // Username Validation
    let username = document.getElementById("username").value.trim();
    if (username === "") {
        document.getElementById("usernameError").innerText = "Username is required!";
        isValid = false;
    }

    // Email Validation
    let email = document.getElementById("email").value.trim();
    let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        document.getElementById("emailError").innerText = "Invalid email format!";
        isValid = false;
    }

    // Password Validation
    let password = document.getElementById("password").value;
    if (password.length < 6) {
        document.getElementById("passwordError").innerText = "Password must be at least 6 characters!";
        isValid = false;
    }

    // Prevent form submission if validation fails
    if (!isValid) {
        event.preventDefault();
    }
});

