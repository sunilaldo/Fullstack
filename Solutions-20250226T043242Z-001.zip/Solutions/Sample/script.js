// Function to display an alert message
function showMessage() {
    alert("Hello! This message is from an external JavaScript file.");
}

