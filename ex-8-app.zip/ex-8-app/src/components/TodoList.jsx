import React, { useState } from 'react';
    const TodoList = () => {
    const [tasks, setTasks] = useState([]);   // For storing the tasks
    const [task, setTask] = useState('');     // For capturing user input
    const addTask = () => {
        if (task.trim()) {
        setTasks([...tasks, task]);          // Add new task to the task array
        setTask('');                         // Clear input field
        }
    };
    return (
        <div>
        <h1>To-Do List</h1>
        <input 
            type="text" 
            value={task} 
            onChange={(e) => setTask(e.target.value)} 
            placeholder="Add a new task" 
        />
        <button onClick={addTask}>Add Task</button>
        <ul>
            {tasks.map((t, index) => (
            <li key={index}>{t}</li>
            ))}
        </ul>
        </div>
    );
    };
    export default TodoList;